library(testthat)
library(aegis)

test_check("aegis")
