## Private functions
detectCores <- parallelly:::detectCores
hpaste <- parallelly:::hpaste
inRCmdCheck <- parallelly:::inRCmdCheck
mdebug <- parallelly:::mdebug
mdebugf <- parallelly:::mdebugf
pid_exists <- parallelly:::pid_exists
isFALSE <- parallelly:::isFALSE

stopf <- parallelly:::stopf
warnf <- parallelly:::warnf
msgf <- parallelly:::msgf
stealth_sample <- parallelly:::stealth_sample
supportsMulticoreAndRStudio <- parallelly:::supportsMulticoreAndRStudio
registerClusterTypes <- parallelly:::registerClusterTypes
isForkedNode <- parallelly:::isForkedNode
update_package_options <- parallelly:::update_package_options
