## Private future.callr functions
await <- future.callr:::await
import_future <- future.callr:::import_future
is_false <- future.callr:::is_false
is_na <- future.callr:::is_na
is_os <- future.callr:::is_os
hpaste <- future.callr:::hpaste
mdebug <- future.callr:::mdebug
mdebugf <- future.callr:::mdebugf
mprint <- future.callr:::mprint
mstr <- future.callr:::mstr
printf <- future.callr:::printf
trim <- future.callr:::trim
commaq <- future.callr:::commaq
