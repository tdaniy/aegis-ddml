## Record original state
ovars <- ls(envir = globalenv())
oenvs <- oenvs0 <- Sys.getenv()
oopts0 <- options()
