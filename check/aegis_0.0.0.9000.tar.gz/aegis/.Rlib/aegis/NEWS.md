# aegis 0.0.0.9000

- Added Phase B package scaffold (constructors, placeholder fit object, methods, and API tests).
